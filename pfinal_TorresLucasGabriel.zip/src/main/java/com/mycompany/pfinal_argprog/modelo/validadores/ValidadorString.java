/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pfinal_argprog.modelo.validadores;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author lucas
 */
public class ValidadorString implements IValidadores {

    private final String nombre;
    private final String apellido;
    private final String telefono;
    
    public ValidadorString(String nombre, String apellido, String telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
    }
    @Override
    public boolean validar() {
        Pattern pattern = Pattern.compile("[a-zA-z-\\d]{1,40}", Pattern.CASE_INSENSITIVE);
        Matcher m1 = pattern.matcher(this.nombre);
        Matcher m2 = pattern.matcher(this.apellido);
        Matcher m3 = pattern.matcher(this.telefono);
        return m1.find() && m2.find() && m3.find();
    }

    @Override
    public String obtener_error() {
        return "ERROR: Algun campo está vacio, tiene un valor demasiado largo o tiene formato inválido";
    }
    
}
